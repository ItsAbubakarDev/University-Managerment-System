import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Person {
    private String name;
    private String email;
    private String dateOfBirth;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(name.isEmpty()){
            while(name.isEmpty()){
                name = JOptionPane.showInputDialog("Enter the valid name: ");
                this.name = name;
            }
        }
        this.name = name;
    }

    public String getEmail() {
        return email;
    }
    public boolean isValidEmail(String email){
        return email!=null && email.contains("@gmail.com");
    }

    public void setEmail(String email) {
        if(!(isValidEmail(email))){
            while(!(isValidEmail(email))){
                email = JOptionPane.showInputDialog("Enter the correct email");
                this.email = email;
            }
        }
        else{
            this.email = email;
        }
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }
    public boolean isValidDateOfBirth(String dateOfBirth){
        try{
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate.parse(dateOfBirth,formatter);
            return true;
        }
        catch (DateTimeParseException e){
            return false;
        }
    }

    public void setDateOfBirth(String dateOfBirth) {
        if(!(isValidDateOfBirth(dateOfBirth))){
            while(!(isValidDateOfBirth(dateOfBirth))){
                dateOfBirth = JOptionPane.showInputDialog("Enter valid Date of Birth (yyyy-MM-dd)");
                this.dateOfBirth = dateOfBirth;
            }
        }
        else{
            this.dateOfBirth = dateOfBirth;

        }
    }

    public Person(String name, String email, String dateOfBirth) {
        this.name = name;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
    }
    public Person(){

    }
}