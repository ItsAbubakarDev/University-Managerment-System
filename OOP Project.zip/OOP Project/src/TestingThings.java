import javax.swing.*;
import java.util.Scanner;
class TestingThings {
    public static void main(String[] args) {
        //Student s = new Student();
        //
        //Teacher t = new Teacher();
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(JOptionPane.showInputDialog("Enter a number"));
        JOptionPane.showMessageDialog(null,n);


    }
}






