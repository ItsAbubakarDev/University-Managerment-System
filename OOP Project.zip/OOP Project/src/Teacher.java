import javax.swing.*;
import java.util.ArrayList;

public class Teacher<T> extends Person implements Reportable {
    private T teacherID;
    private String specialization;
    private ArrayList<CourseManagement> listofCoursesTaught;
    public static ArrayList<T> uniqueIDs = new ArrayList<>();
    public static int noOfTeachers = 0;

    // Constructors
    public Teacher(String name, String email, String dateOfBirth, T teacherID, String specialization) {
        super(name, email, dateOfBirth);
        this.teacherID = teacherID;
        this.specialization = specialization;
        this.listofCoursesTaught = new ArrayList<>();
        noOfTeachers++;
    }

    public Teacher(T teacherID, String specialization) {
        this.teacherID = teacherID;
        this.specialization = specialization;
        this.listofCoursesTaught = new ArrayList<>();
        noOfTeachers++;
    }

    public Teacher(){
        this.setTeacherID((T) JOptionPane.showInputDialog("Enter Teacher ID: "));
        this.setName(JOptionPane.showInputDialog("Enter Teacher name: "));
        this.setEmail(JOptionPane.showInputDialog("Enter the email: "));
        this.setDateOfBirth(JOptionPane.showInputDialog("Enter date of birth: "));
        this.setSpecialization(JOptionPane.showInputDialog("Enter specialization: "));
        this.listofCoursesTaught = new ArrayList<>();
        noOfTeachers++;
    }

    private boolean isUniqueID(T teacherID) {
        return !uniqueIDs.contains(teacherID);
    }

    // Getters and Setters
    public T getTeacherID() {
        return teacherID;
    }

    public void setTeacherID(T teacherID) {
        if (!isUniqueID(teacherID)) {
            while (!isUniqueID(teacherID)) {
                teacherID = (T) JOptionPane.showInputDialog("Enter a unique ID: ");
            }
        }
        this.teacherID = teacherID;
        uniqueIDs.add(teacherID);
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public ArrayList<CourseManagement> getListofCoursesTaught() {
        return listofCoursesTaught;
    }

    public void setListofCoursesTaught(ArrayList<CourseManagement> listofCoursesTaught) {
        this.listofCoursesTaught = listofCoursesTaught;
    }

    public static int getNoOfTeachers() {
        return noOfTeachers;
    }

    public static void setNoOfTeachers(int noOfTeachers) {
        Teacher.noOfTeachers = noOfTeachers;
    }

    // Methods
    public void assignCourse(CourseManagement course) {
        if (!listofCoursesTaught.contains(course)) {
            listofCoursesTaught.add(course);
            course.setAssignedTeacher(this);
            System.out.println("Teacher " + teacherID + " assigned to teach " + course.getCourseTitle());
        } else {
            System.out.println("Teacher " + teacherID + " is already assigned to " + course.getCourseTitle());
        }
    }

    public void displayCourses() {
        System.out.println("Courses taught by " + teacherID + ":");
        for (CourseManagement course : listofCoursesTaught) {
            System.out.println("- " + course.getCourseTitle() + " (ID: " + course.getCourseID() + ")");
        }
    }

    @Override
    public void generateReport() {
        JOptionPane.showMessageDialog(null, "Teacher Report : \n ID: " + teacherID + "\n Name: " + getName() + "\n Specialization: " + getSpecialization());
        System.out.println("Teacher Report:");
        System.out.println("ID: " + teacherID);
        System.out.println("Name: " + getName());
        System.out.println("Specialization: " + specialization);
        System.out.println("Courses Taught:");
        for (CourseManagement course : listofCoursesTaught) {
            System.out.println("- " + course.getCourseTitle() + " (Credits: " + course.getCredits() + ")");
        }
    }

    @Override
    public void exportToFile() {
        // Implement file writing logic
        System.out.println("Exporting teacher report for " + teacherID + " to file...");
    }

    @Override
    public String toString() {
        return "Teacher: " + teacherID + ", Name: " + getName() + ", Specialization: " + specialization
                + ", Courses Taught: " + listofCoursesTaught.size();
    }
}
