import java.util.ArrayList;
import javax.swing.*;

public class Student<S> extends Person {
    private S studentID;
    private String address;
    private ArrayList<CourseManagement> enrolledCourses;
    public static ArrayList<S> uniqueIDs = new ArrayList<>();
    public static int noOfStudents = 0;

    // Constructors
    public Student(String name, String email, String dateOfBirth, S studentID, String address) {
        super(name, email, dateOfBirth);
        this.studentID = studentID;
        this.address = address;
        this.enrolledCourses = new ArrayList<>();
        noOfStudents++;
    }

    // Ensure unique studentID
    private boolean isUniqueID(S studentID) {
        return !uniqueIDs.contains(studentID);
    }

    // Getters and Setters
    public S getStudentID() {
        return studentID;
    }

    public void setStudentID(S studentID) {
        // Make sure the studentID is unique
        while (!isUniqueID(studentID)) {
            studentID = (S) JOptionPane.showInputDialog("Enter a unique ID: ");
        }
        this.studentID = studentID;
        uniqueIDs.add(studentID);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<CourseManagement> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(ArrayList<CourseManagement> enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }

    public static int getNoOfStudents() {
        return noOfStudents;
    }

    public static void setNoOfStudents(int noOfStudents) {
        Student.noOfStudents = noOfStudents;
    }

    public Student() {
        JOptionPane.showMessageDialog(null, "You have to add student data before enrolling a student");
        this.setStudentID((S) JOptionPane.showInputDialog("Enter Student ID:"));
        this.setName(JOptionPane.showInputDialog("Enter Student Name:"));
        this.setEmail(JOptionPane.showInputDialog("Enter Student Email:"));
        this.setDateOfBirth(JOptionPane.showInputDialog("Enter Date of Birth (YYYY-MM-DD):"));
        this.address = JOptionPane.showInputDialog("Enter Student Address:");

        this.enrolledCourses = new ArrayList<>();
        noOfStudents++;
    }

    // Methods
    public void enrollInCourse(CourseManagement course) {
        if (enrolledCourses.contains(course)) {
            System.out.println("Student " + studentID + " is already enrolled in " + course.getCourseTitle());
        } else {
            enrolledCourses.add(course);
            course.addStudent(this);
            System.out.println("Student " + studentID + " successfully enrolled in " + course.getCourseTitle());
        }
    }

    public void displayCourses() {
        if (enrolledCourses.isEmpty()) {
            System.out.println("Student " + studentID + " is not enrolled in any courses.");
        } else {
            System.out.println("Courses for Student " + studentID + ":");
            for (CourseManagement course : enrolledCourses) {
                System.out.println("- " + course.getCourseTitle() + " (Credits: " + course.getCredits() + ")");
            }
        }
    }

    @Override
    public String toString() {
        return "Student: " + studentID + ", Name: " + getName() + ", Address: " + address + ", Enrolled in: "
                + enrolledCourses.size() + " courses.";
    }
}
