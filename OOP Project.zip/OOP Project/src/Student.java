import java.util.ArrayList;
import javax.swing.*;
public class Student extends Person {
    private String studentID;
    private String address;
    private ArrayList<CourseManagement> enrolledCourses;
    public static ArrayList<String> uniqueIDs = new ArrayList<>();
    public static int noOfStudents = 0;

    // Constructors
    public Student(String name, String email, String dateOfBirth, String studentID, String address) {
        super(name, email, dateOfBirth);
        this.studentID = studentID;
        this.address = address;
        this.enrolledCourses = new ArrayList<>(); // Initialize to avoid null pointer issues
        noOfStudents++;
    }

    private boolean isUniqueID(String studentID) {
        return !uniqueIDs.contains(studentID);
    }

    // Getters and Setters
    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        if (!isUniqueID(studentID)) {
            while (!isUniqueID(studentID)) {
                studentID = JOptionPane.showInputDialog("Enter a unique ID: ");
            }
        }
        this.studentID = studentID;
        uniqueIDs.add(studentID);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<CourseManagement> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(ArrayList<CourseManagement> enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }

    public static int getNoOfStudents() {
        return noOfStudents;
    }

    public static void setNoOfStudents(int noOfStudents) {
        Student.noOfStudents = noOfStudents;
    }

    public Student(String studentID, String address) {
        this.studentID = studentID;
        this.address = address;
        this.enrolledCourses = new ArrayList<>();
        noOfStudents++;
    }
    public Student() {
        JOptionPane.showMessageDialog(null,"You have to add student data before enrolling a student");
        // Prompt user for input using JOptionPane
        this.setStudentID(JOptionPane.showInputDialog("Enter Student ID:"));
        this.setName(JOptionPane.showInputDialog("Enter Student Name:")); // Call superclass method to set name
        this.setEmail(JOptionPane.showInputDialog("Enter Student Email:")); // Call superclass method to set email
        this.setDateOfBirth(JOptionPane.showInputDialog("Enter Date of Birth (YYYY-MM-DD):")); // Call superclass method for DOB
        this.address = JOptionPane.showInputDialog("Enter Student Address:");

        // Initialize the list of courses
        this.enrolledCourses = new ArrayList<>();

        // Increment the count of students
        noOfStudents++;
    }




    // Methods
    public void enrollInCourse(CourseManagement course) {
        if (enrolledCourses.contains(course)) {
            System.out.println("Student " + studentID + " is already enrolled in " + course.getCourseTitle());
        } else {
            enrolledCourses.add(course);
            course.addStudent(this); // Ensure course knows about the student
            System.out.println("Student " + studentID + " successfully enrolled in " + course.getCourseTitle());
        }
    }

    public void displayCourses() {
        if (enrolledCourses.isEmpty()) {
            System.out.println("Student " + studentID + " is not enrolled in any courses.");
        } else {
            System.out.println("Courses for Student " + studentID + ":");
            for (CourseManagement course : enrolledCourses) {
                System.out.println("- " + course.getCourseTitle() + " (Credits: " + course.getCredits() + ")");
            }
        }
    }

    // Override toString
    @Override
    public String toString() {
        return "Student: " + studentID + ", Name: " + getName() + ", Address: " + address + ", Enrolled in: "
                + enrolledCourses.size() + " courses.";
    }

}
