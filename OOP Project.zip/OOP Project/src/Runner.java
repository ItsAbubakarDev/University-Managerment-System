import java.util.ArrayList;
import javax.swing.*;

public class Runner {
    public static void main(String[] args) {
        // Create a list to manage students
        ArrayList<Student> students = new ArrayList<>();
        ArrayList<CourseManagement> courses = new ArrayList<>();

        // Menu-driven program
        while (true) {
            String menu = """                            
                Choose an option:
                1. Add a new student
                2. Add a new course
                3. Enroll a student in a course
                4. Display all students
                5. Display all courses
                6. Display courses of a specific student
                7. Exit
                """;


            String choice = JOptionPane.showInputDialog(menu);
            if (choice == null || choice.equals("7")) {
                JOptionPane.showMessageDialog(null, "Exiting program. Goodbye!");
                break;
            }

            switch (choice) {
                case "1" -> {
                    // Add a new student
                    Student newStudent = new Student(); // Using the no-argument constructor
                    students.add(newStudent);
                    JOptionPane.showMessageDialog(null, "Student added: " + newStudent);
                }
                case "2" -> {
                    // Add a new course

                    CourseManagement newCourse = new CourseManagement();
                    courses.add(newCourse);
                    JOptionPane.showMessageDialog(null, "Course added: " + newCourse);
                }
                case "3" -> {
                    // Enroll a student in a course
                    if (students.isEmpty() || courses.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No students or courses available for enrollment.");
                        continue;
                    }

                    String studentID = JOptionPane.showInputDialog("Enter Student ID for enrollment:");
                    Student selectedStudent = students.stream()
                            .filter(student -> student.getStudentID().equals(studentID))
                            .findFirst()
                            .orElse(null);

                    if (selectedStudent == null) {
                        JOptionPane.showMessageDialog(null, "Student not found!");
                        continue;
                    }

                    String courseID = JOptionPane.showInputDialog("Enter Course ID to enroll:");
                    CourseManagement selectedCourse = courses.stream()
                            .filter(course -> course.getCourseID().equals(courseID))
                            .findFirst()
                            .orElse(null);

                    if (selectedCourse == null) {
                        JOptionPane.showMessageDialog(null, "Course not found!");
                        continue;
                    }

                    selectedStudent.enrollInCourse(selectedCourse);
                }
                case "4" -> {
                    // Display all students
                    if (students.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No students available.");
                    } else {
                        StringBuilder sb = new StringBuilder("Students List:\n");
                        for (Student student : students) {
                            sb.append(student).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, sb.toString());
                    }
                }
                case "5" -> {
                    // Display all courses
                    if (courses.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No courses available.");
                    } else {
                        StringBuilder sb = new StringBuilder("Courses List:\n");
                        for (CourseManagement course : courses) {
                            sb.append(course).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, sb.toString());
                    }
                }
                case "6" -> {
                    // Display courses of a specific student
                    if (students.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No students available.");
                        continue;
                    }

                    String studentID = JOptionPane.showInputDialog("Enter Student ID:");
                    Student selectedStudent = students.stream()
                            .filter(student -> student.getStudentID().equals(studentID))
                            .findFirst()
                            .orElse(null);

                    if (selectedStudent == null) {
                        JOptionPane.showMessageDialog(null, "Student not found!");
                        continue;
                    }

                    selectedStudent.displayCourses();
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }
}
