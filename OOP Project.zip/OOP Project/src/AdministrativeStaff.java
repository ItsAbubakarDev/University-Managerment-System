import javax.swing.*;
import java.util.ArrayList;

public class AdministrativeStaff<A> extends Person implements Reportable {
    private A staffID;
    private String role;
    private String department;
    public static ArrayList<A> uniqueIDs = new ArrayList<>();

    // Constructors
    public AdministrativeStaff(String name, String email, String dateOfBirth, A staffID, String role, String department) {
        super(name, email, dateOfBirth);
        this.staffID = staffID;
        this.role = role;
        this.department = department;
    }

    public AdministrativeStaff(A staffID, String role, String department) {
        this.staffID = staffID;
        this.role = role;
        this.department = department;
    }

    // Default constructor
    public AdministrativeStaff() {
        // Optional: Initialize default values if needed
    }

    // Getters and Setters
    public A getStaffID() {
        return staffID;
    }

    private boolean isUniqueID(A staffID) {
        return !uniqueIDs.contains(staffID);
    }

    public void setStaffID(A staffID) {
        // Check if the ID is unique
        if (!(isUniqueID(staffID))) {
            while (!(isUniqueID(staffID))) {
                String input = JOptionPane.showInputDialog("Enter unique ID:");

                // Handle conversion if necessary
                // Example for String input; adapt based on your needs (e.g., Integer)
                if (staffID instanceof String) {
                    this.staffID = (A) input;
                } else {
                    // If staffID is Integer, for example:
                    try {
                        this.staffID = (A) Integer.valueOf(input);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input, please enter a valid number.");
                    }
                }
            }
        }
        uniqueIDs.add(staffID);
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    // Methods
    public void generateReport(ArrayList<Person> people) {
        System.out.println("Administrative Staff Report:");
        for (Person person : people) {
            if (person instanceof Student) {
                Student student = (Student) person;
                System.out.println("Student ID: " + student.getStudentID() + ", Name: " + student.getName() + ", Enrolled Courses: " + student.getEnrolledCourses().size());
            } else if (person instanceof Teacher) {
                Teacher teacher = (Teacher) person;
                System.out.println("Teacher ID: " + teacher.getTeacherID() + ", Name: " + teacher.getName() + ", Courses Taught: " + teacher.getListofCoursesTaught().size());
            } else if (person instanceof AdministrativeStaff) {
                AdministrativeStaff staff = (AdministrativeStaff) person;
                System.out.println("Staff ID: " + staff.getStaffID() + ", Name: " + staff.getName() + ", Department: " + staff.getDepartment());
            }
        }
    }

    @Override
    public void generateReport() {
        System.out.println("Administrative Staff Report for " + staffID + ":");
        System.out.println("Name: " + getName());
        System.out.println("Role: " + role);
        System.out.println("Department: " + department);
    }

    @Override
    public void exportToFile() {
        // Placeholder for file export functionality
        System.out.println("Exporting administrative staff report for " + staffID + " to file...");
    }

    @Override
    public String toString() {
        return "Administrative Staff: ID = " + staffID + ", Name = " + getName() + ", Role = " + role + ", Department = " + department;
    }
}
