import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;

public class CourseManagement {
    private String courseID;
    private String courseTitle;
    private int credits;
    private Teacher assignedTeacher;
    public static ArrayList<String> uniqueIDs = new ArrayList<>();
    private ArrayList<Student> enrolledStudents;
    private ArrayList<Integer> studentGrades; // Stores grades for enrolled students
    public static int noOfCourses = 0;

    // Constructors
    public CourseManagement(String courseID, String courseTitle, int credits) {
        this.courseID = courseID;
        this.courseTitle = courseTitle;
        this.credits = credits;
        this.enrolledStudents = new ArrayList<>();
        this.studentGrades = new ArrayList<>();
        noOfCourses++;
    }

    public CourseManagement() {
        this.setCourseID(JOptionPane.showInputDialog("Enter Course ID:"));
        this.setCourseTitle(JOptionPane.showInputDialog("Enter Course Title:"));
        this.setCredits(Integer.parseInt(JOptionPane.showInputDialog("Enter number of Credits:")));

        // Assign teacher interactively
        //here is an error
        String teacherName = JOptionPane.showInputDialog("Enter Assigned Teacher's Name:");
//        this.setAssignedTeacher(new Teacher(teacherName, "", "", "", "", new ArrayList<>()));

        // Enroll students interactively
        enrolledStudents = new ArrayList<>();
        studentGrades = new ArrayList<>();
        int noOfStudents = Integer.parseInt(JOptionPane.showInputDialog("Enter number of students to enroll:"));
        for (int i = 0; i < noOfStudents; i++) {
            String studentName = JOptionPane.showInputDialog("Enter Student " + (i + 1) + " Name:");
            enrolledStudents.add(new Student(studentName, "", "", "", ""));
            studentGrades.add(0); // Default grade
        }

        noOfCourses++;
    }

    // Getters and Setters
    public String getCourseID() {
        return courseID;
    }

    private boolean isUniqueID(String courseID) {
        return !uniqueIDs.contains(courseID);
    }

    public void setCourseID(String courseID) {
        if (!isUniqueID(courseID)) {
            while (!isUniqueID(courseID)) {
                courseID = JOptionPane.showInputDialog("Enter a unique ID: ");
            }
        } this.courseID = courseID;
        uniqueIDs.add(courseID);
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public Teacher getAssignedTeacher() {
        return assignedTeacher;
    }

    public void setAssignedTeacher(Teacher assignedTeacher) {
        this.assignedTeacher = assignedTeacher;
        System.out.println("Teacher " + assignedTeacher.getName() + " assigned to teach " + courseTitle);
    }

    public ArrayList<Student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public void setEnrolledStudents(ArrayList<Student> enrolledStudents) {
        this.enrolledStudents = enrolledStudents;
    }

    public static int getNoOfCourses() {
        return noOfCourses;
    }

    public static void setNoOfCourses(int noOfCourses) {
        CourseManagement.noOfCourses = noOfCourses;
    }

    // Methods
    public void addStudent(Student student) {
        if (enrolledStudents.contains(student)) {
            System.out.println("Student " + student.getStudentID() + " is already enrolled in " + courseTitle);
        } else {
            enrolledStudents.add(student);
            studentGrades.add(0); // Default grade
            System.out.println("Student " + student.getStudentID() + " added to " + courseTitle);
        }
    }

    public void removeStudent(Student student) {
        int index = enrolledStudents.indexOf(student);
        if (index != -1) {
            enrolledStudents.remove(student);
            studentGrades.remove(index);
            System.out.println("Student " + student.getStudentID() + " removed from " + courseTitle);
        } else {
            System.out.println("Student " + student.getStudentID() + " is not enrolled in " + courseTitle);
        }
    }

    public void calculateAvgGrades() {
        if (studentGrades.isEmpty()) {
            System.out.println("No students have grades in " + courseTitle);
            return;
        }
        double total = 0;
        for (int grade : studentGrades) {
            total += grade;
        }
        double avg = total / studentGrades.size();
        System.out.println("Average grade for " + courseTitle + ": " + avg);
    }

    public void calculateMedianGrade() {
        if (studentGrades.isEmpty()) {
            System.out.println("No students have grades in " + courseTitle);
            return;
        }
        Collections.sort(studentGrades);
        double median;
        int size = studentGrades.size();
        if (size % 2 == 0) {
            median = (studentGrades.get(size / 2 - 1) + studentGrades.get(size / 2)) / 2.0;
        } else {
            median = studentGrades.get(size / 2);
        }
        System.out.println("Median grade for " + courseTitle + ": " + median);
    }

    @Override
    public String toString() {
        return "Course: " + courseTitle + " (ID: " + courseID + ", Credits: " + credits
                + ", Teacher: " + assignedTeacher.getName() ;
    }
}
