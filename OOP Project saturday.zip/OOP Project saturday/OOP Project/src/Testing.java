public class Testing {
    public static void main(String[] args) {
        Teacher teacher1 = new Teacher("Asma","asma@comsats.com","2000-12-12","FA23","Computer Science");
        Teacher teacher2 = new Teacher("Sara","sara@comsats.com", "2000-13-14", "FA22","EE");
        teacher1.exportToFile();
        teacher2.exportToFile();
        AdministrativeStaff staff1 = new AdministrativeStaff();
        staff1.exportToFile();
    }
}
