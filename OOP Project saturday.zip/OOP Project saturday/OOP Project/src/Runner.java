import java.util.ArrayList;
import javax.swing.*;

public class Runner {
    private static final ArrayList<Student> students = new ArrayList<>();
    private static final ArrayList<CourseManagement> courses = new ArrayList<>();
    private static final ArrayList<Teacher> teachers = new ArrayList<>();


    public static void main(String[] args) {
        // Menu-driven program
        while (true) {
            String menu = """
                Choose an option:
                1. Add a new student
                2. Add a Teacher
                3. Add a new course
                4. Enroll a student in a course
                5. Display all students
                6. Display all Teachers
                7. Display all courses
                8. Display courses of a specific student
                9. Assign course to a Teacher
                10.Display Report
                11. Exit
                """;

            String choice = JOptionPane.showInputDialog(menu);
            if (choice == null || choice.equals("11")) {
                JOptionPane.showMessageDialog(null, "Exiting program. Goodbye!");
                break;
            }

            switch (choice) {
                case "1" -> addStudent();
                case "2" -> addTeacher();
                case "3" -> addCourse();
                case "4" -> enrollStudentInCourse();
                case "5" -> displayAllStudents();
                case "6" -> displayAllTeachers();
                case "7" -> displayAllCourses();
                case "8" -> displayStudentCourses();
                case "9" -> assignCourseToTeacher();
                default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }

    // Add a new student
    private static void addStudent() {
        Student newStudent = new Student();
        students.add(newStudent);
        JOptionPane.showMessageDialog(null, "Student added successfully:\n" + newStudent);
    }

    private static void addTeacher(){
        Teacher newTeacher = new Teacher();
        teachers.add(newTeacher);
        JOptionPane.showMessageDialog(null,"Teacher added successfully:\n" + newTeacher);

    }

    // Add a new course
    private static void addCourse() {
        CourseManagement newCourse = new CourseManagement();
        courses.add(newCourse);
        JOptionPane.showMessageDialog(null, "Course added successfully:\n" + newCourse);
    }

    // Enroll a student in a course
    private static void enrollStudentInCourse() {
        if (students.isEmpty() || courses.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No students or courses available for enrollment.");
            return;
        }

        Student selectedStudent = selectStudent();
        if (selectedStudent == null) return;

        CourseManagement selectedCourse = selectCourse();
        if (selectedCourse == null) return;

        selectedStudent.enrollInCourse(selectedCourse);
        JOptionPane.showMessageDialog(null, "Student enrolled in course successfully!");
    }

    // Display all students
    private static void displayAllStudents() {
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No students available.");
        } else {
            StringBuilder sb = new StringBuilder("Students List:\n");
            for (Student student : students) {
                sb.append(student).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    //display all Teachers
    private static void displayAllTeachers() {
        if (teachers.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No teachers available.");
        } else {
            StringBuilder sb = new StringBuilder("Teacher List:\n");
            for (Teacher teacher: teachers) {
                sb.append(teacher).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }


    // Display all courses
    private static void displayAllCourses() {
        if (courses.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No courses available.");
        } else {
            StringBuilder sb = new StringBuilder("Courses List:\n");
            for (CourseManagement course : courses) {
                sb.append(course).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // Display courses of a specific student
    private static void displayStudentCourses() {
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No students available.");
            return;
        }

        Student selectedStudent = selectStudent();
        if (selectedStudent == null) return;

        selectedStudent.displayCourses();
    }

    // Helper method to select a student
    private static Student selectStudent() {
        String studentID = JOptionPane.showInputDialog("Enter Student ID:");
        for(Student student : students){
            if(student.getStudentID().equals(studentID)){
                return student;
            }

        }
        return null;
    }

    //assigning course to a Teacher
    private static void assignCourseToTeacher(){
        String teacherID = JOptionPane.showInputDialog("Enter the Teacher Id");
        String courseID = JOptionPane.showInputDialog("Enter the Course id");


        for(CourseManagement course : courses){
            if(course.getCourseID().equals(courseID)){
                for(Teacher teacher : teachers){
                    if(teacher.getTeacherID().equals(teacherID)){
                        teacher.assignCourse(course);
                        break;
                    }
                }
                    JOptionPane.showMessageDialog(null,"Teacher not found");
            }
        }
        JOptionPane.showMessageDialog(null,"Invalid CourseID");

    }

    // Helper method to select a course
    private static CourseManagement selectCourse() {
        String courseID = JOptionPane.showInputDialog("Enter Course ID:");
        CourseManagement selectedCourse = courses.stream()
                .filter(course -> course.getCourseID().equals(courseID))
                .findFirst()
                .orElse(null);

        if (selectedCourse == null) {
            JOptionPane.showMessageDialog(null, "Course not found!");
        }
        return selectedCourse;
    }
}
