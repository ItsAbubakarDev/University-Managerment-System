import javax.swing.*;
import java.io.*;
import java.util.*;

public class Teacher extends Person implements Reportable ,Serializable{
    private String teacherID;
    private String specialization;
    private ArrayList<CourseManagement> listofCoursesTaught;
    public static ArrayList<String> uniqueIDs = new ArrayList<>();
    public static int noOfTeachers = 0;


    // Constructors
    public Teacher(String name, String email, String dateOfBirth, String teacherID, String specialization) {
        super(name, email, dateOfBirth);
        setTeacherID(teacherID); // Validate and set unique ID
        this.specialization = specialization;
        this.listofCoursesTaught = new ArrayList<>(); // Initialize to avoid null pointer issues
        noOfTeachers++;
    }

    public Teacher() {
        JOptionPane.showMessageDialog(null, "You have to add teacher data before assigning a teacher.");
        setTeacherID(JOptionPane.showInputDialog("Enter Teacher ID:"));
        setName(JOptionPane.showInputDialog("Enter Teacher Name:"));
        setEmail(JOptionPane.showInputDialog("Enter Teacher Email:"));
        setDateOfBirth(JOptionPane.showInputDialog("Enter Date of Birth (YYYY-MM-DD):"));
        setSpecialization(JOptionPane.showInputDialog("Enter Specialization:"));
        this.listofCoursesTaught = new ArrayList<>();
        noOfTeachers++;
    }

    private boolean isUniqueID(String teacherID) {
        return !uniqueIDs.contains(teacherID);
    }

    // Getters and Setters
    public String getTeacherID() {
        return teacherID;
    }

    public void setTeacherID(String teacherID) {
        while (teacherID == null || teacherID.trim().isEmpty() || !isUniqueID(teacherID)) {
            teacherID = JOptionPane.showInputDialog("Invalid or duplicate ID. Enter a unique Teacher ID:");
        }
        this.teacherID = teacherID;
        uniqueIDs.add(teacherID);
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public ArrayList<CourseManagement> getListofCoursesTaught() {
        return listofCoursesTaught;
    }

    public void setListofCoursesTaught(ArrayList<CourseManagement> listofCoursesTaught) {
        this.listofCoursesTaught = listofCoursesTaught;
    }

    public static int getNoOfTeachers() {
        return noOfTeachers;
    }

    public static void setNoOfTeachers(int noOfTeachers) {
        Teacher.noOfTeachers = noOfTeachers;
    }

    // Methods
    public void assignCourse(CourseManagement course) {
        if (!listofCoursesTaught.contains(course)) {
            listofCoursesTaught.add(course);
            course.setAssignedTeacher(this);
            System.out.println("Teacher " + teacherID + " assigned to teach " + course.getCourseTitle());
        } else {
            System.out.println("Teacher " + teacherID + " is already assigned to " + course.getCourseTitle());
        }
    }

    public void displayCourses() {
        if (listofCoursesTaught.isEmpty()) {
            System.out.println("Teacher " + teacherID + " is not teaching any courses.");
        } else {
            System.out.println("Courses taught by " + teacherID + ":");
            for (CourseManagement course : listofCoursesTaught) {
                System.out.println("- " + course.getCourseTitle() + " (ID: " + course.getCourseID() + ")");
            }
        }
    }

    @Override
    public void generateReport() {
        JOptionPane.showMessageDialog(null, "Teacher Report:\nID: " + teacherID + "\nName: " + getName() +
                "\nSpecialization: " + getSpecialization() + "\nCourses Taught: " + listofCoursesTaught.size());
        System.out.println("Teacher Report:");
        System.out.println("ID: " + teacherID);
        System.out.println("Name: " + getName());
        System.out.println("Specialization: " + specialization);
        System.out.println("Courses Taught:");
        for (CourseManagement course : listofCoursesTaught) {
            System.out.println("- " + course.getCourseTitle() + " (Credits: " + course.getCredits() + ")");
        }
    }

    @Override
    public void exportToFile() {
        // Implement file writing logic if required
        try (FileOutputStream fos = new FileOutputStream("Teacher_Report.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {

            oos.writeObject(this);  // Write the entire teacherObjects list to the file

        } catch (IOException e) {
            System.out.println("Error exporting to file: " + e.getMessage());
        }

        System.out.println("Exporting teacher report for " + teacherID + " to file...");
    }


    @Override
    public String toString() {
        return "Teacher: " + teacherID + ", Name: " + getName() + ", Specialization: " + specialization
                + ", Courses Taught: " + listofCoursesTaught.size();
    }
}
