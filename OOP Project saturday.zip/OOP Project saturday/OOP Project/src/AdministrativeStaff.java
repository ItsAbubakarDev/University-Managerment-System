import javax.swing.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class AdministrativeStaff extends Person implements Reportable, Serializable {
    private String staffID;
    private String role;
    private String department;
    public static ArrayList<String> uniqueIDs = new ArrayList<>();


    // Constructors
    public AdministrativeStaff(String name, String email, String dateOfBirth, String staffID, String role, String department) {
        super(name, email, dateOfBirth);
        setStaffID(staffID); // Validate and set unique ID
        this.role = role;
        this.department = department;
    }


    public AdministrativeStaff(String staffID, String role, String department) {
        setStaffID(staffID); // Validate and set unique ID
        this.role = role;
        this.department = department;
    }
    // Default constructor
    public AdministrativeStaff() {
        setStaffID(JOptionPane.showInputDialog("Enter Staff ID:"));
        setName(JOptionPane.showInputDialog("Enter Name:"));
        setEmail(JOptionPane.showInputDialog("Enter Email:"));
        setDateOfBirth(JOptionPane.showInputDialog("Enter Date of Birth (YYYY-MM-DD):"));
        setRole(JOptionPane.showInputDialog("Enter Role:"));
        setDepartment(JOptionPane.showInputDialog("Enter Department:"));
    }


    // Getters and Setters
    public String getStaffID() {
        return staffID;
    }

    private boolean isUniqueID(String studentID) {
        return !uniqueIDs.contains(studentID);
    }

    public void setStaffID(String staffID) {
        while (staffID == null || staffID.trim().isEmpty() || !isUniqueID(staffID)) {
            staffID = JOptionPane.showInputDialog("Invalid or duplicate ID. Enter a unique Staff ID:");
        }
        this.staffID = staffID;
        uniqueIDs.add(staffID);
    }


    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    // Methods
    public void generateReport(ArrayList<Person> people) {
        System.out.println("Administrative Staff Report:");
        for (Person person : people) {
            if (person instanceof Student) {
                Student student = (Student) person;
                System.out.println("Student ID: " + student.getStudentID() + ", Name: " + student.getName() +
                        ", Enrolled Courses: " + student.getEnrolledCourses().size());
            } else if (person instanceof Teacher) {
                Teacher teacher = (Teacher) person;
                System.out.println("Teacher ID: " + teacher.getTeacherID() + ", Name: " + teacher.getName() +
                        ", Courses Taught: " + teacher.getListofCoursesTaught().size());
            } else if (person instanceof AdministrativeStaff) {
                AdministrativeStaff staff = (AdministrativeStaff) person;
                System.out.println("Staff ID: " + staff.getStaffID() + ", Name: " + staff.getName() +
                        ", Department: " + staff.getDepartment());
            }
        }
    }

    @Override
    public void generateReport() {
        System.out.println("Administrative Staff Report for " + staffID + ":");
        System.out.println("Name: " + getName());
        System.out.println("Role: " + role);
        System.out.println("Department: " + department);
    }

    @Override
    public void exportToFile() {
        try{
            FileOutputStream fos = new FileOutputStream("AdministrativeStaff.txt");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
        }catch(Exception e){
            System.out.println(e);
        }
        System.out.println("Exporting administrative staff report for " + staffID + " to file...");
    }

    @Override
    public String toString() {
        return "Administrative Staff: ID = " + staffID + ", Name = " + getName() +
                ", Role = " + role + ", Department = " + department;
    }
}
