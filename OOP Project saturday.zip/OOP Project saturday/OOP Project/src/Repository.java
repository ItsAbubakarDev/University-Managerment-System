import java.util.ArrayList;
import java.util.List;

public class Repository<T> {
    private List<T> items; // List to store objects of type T

    // Constructor
    public Repository() {
        this.items = new ArrayList<>();
    }

    // 1. Add an object of type T to the repository
    public void add(T item) {
        if (!items.contains(item)) {
            items.add(item);
            System.out.println(item.getClass().getSimpleName() + " added to the repository.");
        } else {
            System.out.println(item.getClass().getSimpleName() + " already exists in the repository.");
        }
    }

    // 2. Remove an object of type T from the repository
    public void remove(T item) {
        if (items.remove(item)) {
            System.out.println(item.getClass().getSimpleName() + " removed from the repository.");
        } else {
            System.out.println(item.getClass().getSimpleName() + " not found in the repository.");
        }
    }

    // 3. Get all objects of type T from the repository
    public List<T> getAll() {
        return new ArrayList<>(items); // Return a copy of the list to avoid modification
    }
}
