public interface Reportable {
    void generateReport();
    void exportToFile();
}
