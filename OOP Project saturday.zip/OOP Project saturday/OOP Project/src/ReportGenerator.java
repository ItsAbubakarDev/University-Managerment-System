import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ReportGenerator {
    private final ArrayList<Student> students;
    private final ArrayList<Teacher> teachers;
    private final ArrayList<CourseManagement> courses;

    public ReportGenerator(ArrayList<Student> students, ArrayList<Teacher> teachers, ArrayList<CourseManagement> courses) {
        this.students = students;
        this.teachers = teachers;
        this.courses = courses;
    }

    // Generate a report of students enrolled in a specific course
    public void generateStudentsInCourseReport(String courseID) {
        System.out.println("Report: Students enrolled in course " + courseID);
        for (CourseManagement course : courses) {
            if (course.getCourseID().equals(courseID)) {
                System.out.println("Course: " + course.getCourseTitle());
                for (Student student : course.getEnrolledStudents()) {
                    System.out.println(student);
                }
                return;
            }
        }
        System.out.println("Course with ID " + courseID + " not found.");
    }

    // Generate a report of teacher workload
    public void generateTeacherWorkloadReport() {
        System.out.println("Report: Teacher Workload");
        for (Teacher teacher : teachers) {
            System.out.println("Teacher: " + teacher.getName() + " (ID: " + teacher.getTeacherID() + ")");
            System.out.println("Courses taught: " + teacher.getListofCoursesTaught().size());
            for (CourseManagement course : teacher.getListofCoursesTaught()) {
                System.out.println("  - " + course.getCourseTitle());
            }
        }
    }

    // Generate a summary report with overall system statistics
    public void generateOverallStatisticsReport() {
        System.out.println("Report: Overall System Statistics");
        System.out.println("Total Students: " + students.size());
        System.out.println("Total Teachers: " + teachers.size());
        System.out.println("Total Courses: " + courses.size());
    }

    // Export reports to a file
    public void exportReportToFile(String filename, String reportContent) {
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write(reportContent);
            System.out.println("Report successfully exported to " + filename);
        } catch (IOException e) {
            System.out.println("Error exporting report: " + e.getMessage());
        }
    }

    // Create a formatted report string for students enrolled in a course
    public String createStudentsInCourseReportContent(String courseID) {
        StringBuilder report = new StringBuilder();
        report.append("Report: Students Enrolled in Course " + courseID + "\n");
        for (CourseManagement course : courses) {
            if (course.getCourseID().equals(courseID)) {
                report.append("Course: " + course.getCourseTitle() + "\n");
                for (Student student : course.getEnrolledStudents()) {
                    report.append(student + "\n");
                }
                return report.toString();
            }
        }
        return "Course with ID " + courseID + " not found.\n";
    }
}
