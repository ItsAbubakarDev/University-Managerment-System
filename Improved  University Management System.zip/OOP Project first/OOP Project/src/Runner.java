import java.util.ArrayList;
import javax.swing.*;

public class Runner {
    private static final ArrayList<Student> students = new ArrayList<>();
    private static final ArrayList<CourseManagement> courses = new ArrayList<>();

    public static void main(String[] args) {
        // Menu-driven program
        while (true) {
            String menu = """
                Choose an option:
                1. Add a new student
                2. Add a new course
                3. Enroll a student in a course
                4. Display all students
                5. Display all courses
                6. Display courses of a specific student
                7. Exit
                """;

            String choice = JOptionPane.showInputDialog(menu);
            if (choice == null || choice.equals("7")) {
                JOptionPane.showMessageDialog(null, "Exiting program. Goodbye!");
                break;
            }

            switch (choice) {
                case "1" -> addStudent();
                case "2" -> addCourse();
                case "3" -> enrollStudentInCourse();
                case "4" -> displayAllStudents();
                case "5" -> displayAllCourses();
                case "6" -> displayStudentCourses();
                default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }

    // Add a new student
    private static void addStudent() {
        Student newStudent = new Student();
        students.add(newStudent);
        JOptionPane.showMessageDialog(null, "Student added successfully:\n" + newStudent);
    }

    // Add a new course
    private static void addCourse() {
        CourseManagement newCourse = new CourseManagement();
        courses.add(newCourse);
        JOptionPane.showMessageDialog(null, "Course added successfully:\n" + newCourse);
    }

    // Enroll a student in a course
    private static void enrollStudentInCourse() {
        if (students.isEmpty() || courses.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No students or courses available for enrollment.");
            return;
        }

        Student selectedStudent = selectStudent();
        if (selectedStudent == null) return;

        CourseManagement selectedCourse = selectCourse();
        if (selectedCourse == null) return;

        selectedStudent.enrollInCourse(selectedCourse);
        JOptionPane.showMessageDialog(null, "Student enrolled in course successfully!");
    }

    // Display all students
    private static void displayAllStudents() {
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No students available.");
        } else {
            StringBuilder sb = new StringBuilder("Students List:\n");
            for (Student student : students) {
                sb.append(student).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // Display all courses
    private static void displayAllCourses() {
        if (courses.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No courses available.");
        } else {
            StringBuilder sb = new StringBuilder("Courses List:\n");
            for (CourseManagement course : courses) {
                sb.append(course).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // Display courses of a specific student
    private static void displayStudentCourses() {
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No students available.");
            return;
        }

        Student selectedStudent = selectStudent();
        if (selectedStudent == null) return;

        selectedStudent.displayCourses();
    }

    // Helper method to select a student
    private static Student selectStudent() {
        String studentID = JOptionPane.showInputDialog("Enter Student ID:");
        Student selectedStudent = students.stream()
                .filter(student -> student.getStudentID().equals(studentID))
                .findFirst()
                .orElse(null);

        if (selectedStudent == null) {
            JOptionPane.showMessageDialog(null, "Student not found!");
        }
        return selectedStudent;
    }

    // Helper method to select a course
    private static CourseManagement selectCourse() {
        String courseID = JOptionPane.showInputDialog("Enter Course ID:");
        CourseManagement selectedCourse = courses.stream()
                .filter(course -> course.getCourseID().equals(courseID))
                .findFirst()
                .orElse(null);

        if (selectedCourse == null) {
            JOptionPane.showMessageDialog(null, "Course not found!");
        }
        return selectedCourse;
    }
}
