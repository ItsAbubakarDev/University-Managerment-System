import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Person {
    private String name;
    private String email;
    private String dateOfBirth;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        while (name == null || name.trim().isEmpty()) {
            name = JOptionPane.showInputDialog("Name cannot be empty. Enter a valid name:");
        }
        this.name = name.trim();
    }

    public String getEmail() {
        return email;
    }
    public boolean isValidEmail(String email){
        return email!=null && email.contains("@") && email.endsWith(".com");
    }

    public void setEmail(String email) {
        while (email == null || !isValidEmail(email)) {
            email = JOptionPane.showInputDialog("Invalid email. Enter a valid email (e.g., example@gmail.com):");
        }
        this.email = email.trim();
    }


    public String getDateOfBirth() {
        return dateOfBirth;
    }
    public boolean isValidDateOfBirth(String dateOfBirth){
        try{
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate.parse(dateOfBirth,formatter);
            return true;
        }
        catch (DateTimeParseException e){
            return false;
        }
    }

    public void setDateOfBirth(String dateOfBirth) {
        while (dateOfBirth == null || !isValidDateOfBirth(dateOfBirth)) {
            dateOfBirth = JOptionPane.showInputDialog("Invalid date format. Enter Date of Birth (yyyy-MM-dd):");
        }
        this.dateOfBirth = dateOfBirth.trim();
    }

    public Person(String name, String email, String dateOfBirth) {
        this.name = name;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
    }
    public Person(){

    }

    @Override
    public String toString() {
        return "Person [Name: " + name + ", Email: " + email + ", Date of Birth: " + dateOfBirth + "]";
    }

}