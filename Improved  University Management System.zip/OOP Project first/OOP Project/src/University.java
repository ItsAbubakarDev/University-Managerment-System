import java.io.*;
import java.util.ArrayList;

public class University {
    private ArrayList<Student> students = new ArrayList<>();
    private ArrayList<Teacher> teachers = new ArrayList<>();
    private ArrayList<CourseManagement> courses = new ArrayList<>();

    // Display system stats
    public static void displaySystemStats() {
        System.out.println("Total Students: " + Student.getNoOfStudents());
        System.out.println("Total Teachers: " + Teacher.getNoOfTeachers());
        System.out.println("Total Courses: " + CourseManagement.getNoOfCourses());
    }

    // Student management
    public void addStudent(Student student) {
        students.add(student);
        Student.noOfStudents++; // Incrementing in the Student class
        System.out.println("Student added: " + student.getName());
    }

    public void removeStudent(Student student) {
        if (students.remove(student)) {
            Student.noOfStudents--; // Decrementing in the Student class
            System.out.println("Student removed: " + student.getName());
        } else {
            System.out.println("Student not found: " + student.getName());
        }
    }

    public void updateStudent(Student updatedStudent) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getStudentID().equals(updatedStudent.getStudentID())) {
                students.set(i, updatedStudent);
                System.out.println("Student updated: " + updatedStudent.getName());
                return;
            }
        }
        System.out.println("Student not found: " + updatedStudent.getStudentID());
    }

    // Teacher management
    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
        Teacher.noOfTeachers++; // Incrementing in the Teacher class
        System.out.println("Teacher added: " + teacher.getName());
    }

    public void removeTeacher(Teacher teacher) {
        if (teachers.remove(teacher)) {
            Teacher.noOfTeachers--;  // Decrementing in the Teacher class
            System.out.println("Teacher removed: " + teacher.getName());
        } else {
            System.out.println("Teacher not found: " + teacher.getName());
        }
    }

    public void updateTeacher(Teacher updatedTeacher) {
        for (int i = 0; i < teachers.size(); i++) {
            if (teachers.get(i).getTeacherID().equals(updatedTeacher.getTeacherID())) {
                teachers.set(i, updatedTeacher);
                System.out.println("Teacher updated: " + updatedTeacher.getName());
                return;
            }
        }
        System.out.println("Teacher not found: " + updatedTeacher.getTeacherID());
    }

    // Course management
    public void addCourse(CourseManagement course) {
        courses.add(course);
        CourseManagement.noOfCourses++; // Incrementing in the CourseManagement class
        System.out.println("Course added: " + course.getCourseTitle());
    }

    public void removeCourse(CourseManagement course) {
        if (courses.remove(course)) {
            CourseManagement.noOfCourses--; // Decrementing in the CourseManagement class
            System.out.println("Course removed: " + course.getCourseTitle());
        } else {
            System.out.println("Course not found: " + course.getCourseTitle());
        }
    }

    public void updateCourse(CourseManagement updatedCourse) {
        for (int i = 0; i < courses.size(); i++) {
            if (courses.get(i).getCourseID().equals(updatedCourse.getCourseID())) {
                courses.set(i, updatedCourse);
                System.out.println("Course updated: " + updatedCourse.getCourseTitle());
                return;
            }
        }
        System.out.println("Course not found: " + updatedCourse.getCourseID());
    }

    // Data persistence
    public void saveData(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(students);
            oos.writeObject(teachers);
            oos.writeObject(courses);
            System.out.println("Data saved successfully to " + filename);
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    public void loadData(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            students = (ArrayList<Student>) ois.readObject();
            teachers = (ArrayList<Teacher>) ois.readObject();
            courses = (ArrayList<CourseManagement>) ois.readObject();
            System.out.println("Data loaded successfully from " + filename);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }

    // Searching and filtering
    public void searchStudentByName(String name) {
        System.out.println("Searching for students with name: " + name);
        boolean found = false;
        for (Student student : students) {
            if (student.getName().equalsIgnoreCase(name)) {
                System.out.println(student);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No students found with name: " + name);
        }
    }

    public void filterCoursesByCredits(int minCredits) {
        System.out.println("Filtering courses with minimum credits: " + minCredits);
        boolean found = false;
        for (CourseManagement course : courses) {
            if (course.getCredits() >= minCredits) {
                System.out.println(course);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No courses found with minimum credits of: " + minCredits);
        }
    }
}
